#!/bin/sh
echo -ne '\033c\033]0;VacuumCleaner2D\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/VacuumCleaner2D.x86_64" "$@"
